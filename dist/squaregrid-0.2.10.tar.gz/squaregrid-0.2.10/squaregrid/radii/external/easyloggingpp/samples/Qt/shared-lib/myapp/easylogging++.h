#ifndef EASYLOGGING_H
#define EASYLOGGING_H
#include "../../../../src/easylogging++.h"
#endif // EASYLOGGING_H

def get_build_location():
    print(1)
    pass

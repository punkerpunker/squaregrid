import pandas as pd
import math
import sys
import numpy as np
import getpass
from math import cos, sqrt, sin, radians, acos, floor
from geopy.distance import vincenty
from sqlalchemy import update, select
from mlbase.db.engine import MLData, Loger
from mlhelpers import ml_geocoder


class MetadataCreate:
    def __init__(self, city_dict, db=None):
        if not db:
            self.db = MLData()
        else:
            self.db = db
        for key, value in city_dict.items():
            if key in ['lat', 'lng']:
                setattr(self,  key, float(value))
            else:
                setattr(self, key, value)
        self.city_id = 0
        self.conn = self.db.engine.connect()
        self.squares_coordinates = pd.DataFrame()
        self.loger = Loger('logs.grid_creation_log', self.db)

    def check_existance(self):
        cities_grids = self.db.get_table(schema_name='metadata', table_name='cities_grids')
        same_cities_sql = select([cities_grids.c.town, cities_grids.c.city_id]).where(cities_grids.c.town == self.city)
        for row in self.conn.execute(same_cities_sql):
            self.loger.write_to_log('error', 'City already exists')
            self.loger.push()
            raise Exception('City Already exists')

    def get_country_id(self):
        countries = self.db.get_table(schema_name='metadata', table_name='countries')
        country_sql = select([countries.c.country_id, countries.c.ru_country, countries.c.en_country])\
                             .where(countries.c.ru_country == self.country)
        for row in self.conn.execute(country_sql):
            country_id = row[0]
        try:
            c_id = country_id
            self.loger.write_to_log('country_id', country_id)
        except NameError:
            self.loger.write_to_log('error', 'Unspecified country')
            self.loger.push()
            raise Exception ('Country doesn\'t exist! You need to specify it in metadata.countries')
        return c_id

    def calculate_borders(self):
        latmax = float(self.northeast[0])
        longmax = float(self.northeast[1])
        latmin = float(self.southwest[0])
        longmin = float(self.southwest[1])
        return {'latmax':latmax, 'longmax':longmax, 'latmin':latmin, 'longmin':longmin}

    def calc_distances(self, borders):
        dist_to_north = float(vincenty((self.lat, self.lng), (borders['latmax'], self.lng)).meters) / 1000
        dist_to_south = float(vincenty((self.lat, self.lng), (borders['latmin'], self.lng)).meters) / 1000
        dist_to_east = float(vincenty((self.lat, self.lng), (self.lat, borders['longmax'])).meters) / 1000
        dist_to_west = float(vincenty((self.lat, self.lng), (self.lat, borders['longmin'])).meters) / 1000
        return {'north':dist_to_north, 'south':dist_to_south, 'east':dist_to_east, 'west':dist_to_west}

    def calc_grid_size(self, distances, square_size, manual_gridsize=None):
        if manual_gridsize:
            gridsize = manual_gridsize
            self.loger.write_to_log('gridsize', gridsize)
            self.loger.write_to_log('grid_type', 'manual')
        else:
            maximum = max(distances['north'], distances['south'], distances['east'], distances['west'])
            maximum += 5
            maximum /= 10
            gridsize = math.ceil(maximum)
            gridsize *= 10000/square_size
            self.loger.write_to_log('gridsize', gridsize)
            self.loger.write_to_log('grid_type', 'auto')
        return gridsize

    def calculate_steps(self, square_size):
        latstep = square_size / vincenty((self.lat, self.lng), (self.lat + 1., self.lng)).meters
        longstep = square_size / vincenty((self.lat, self.lng), (self.lat, self.lng+1)).meters
        return [latstep, longstep]

    def get_new_city_id(self):
        cities_grids = self.db.get_table(schema_name='metadata', table_name='cities_grids')
        city_ids_sql = select([cities_grids.c.city_id])
        city_ids = self.conn.execute(city_ids_sql)
        max_id = max(city_ids)[0]
        self.city_id = max_id+1
        self.loger.write_to_log('city_id', max_id+1)
        return max_id+1

    def get_population(self, city_name):
        cities_population = self.db.get_table(schema_name='metadata', table_name='cities_population')
        population_sql = select([cities_population.c.pop]).where(cities_population.c.city == city_name)
        for row in self.conn.execute(population_sql):
            population = row[0]
        try:
            pop = population
            self.loger.write_to_log('population', pop)
            return population
        except UnboundLocalError:
            self.loger.write_to_log('error', 'No Population')
            pass

    def city_grid_to_database(self, cities_grids_attributes, check_dup=True):
        if check_dup:
            self.check_existance()
        else:
            pass
        self.loger.push()
        self.db.insert('metadata.cities_grids', cities_grids_attributes)
        self.db.cur.execute("UPDATE metadata.cities_grids "
                            "SET polygon = ST_MakePolygon(ST_GeomFromText("
                            "CONCAT('LINESTRING(',longmin, ' ', latmin, ',', "
                            "                     longmax, ' ', latmin, ',', "
                            "                     longmax, ' ', latmax, ',',"
                            "                     longmin, ' ', latmax, ',', "
                            "                     longmin, ' ', latmin,')'), 4326)) " 
                            "WHERE city_id = "+str(self.city_id))
        self.db.commit()

    @staticmethod
    def make_it_square(latcenter, longcenter, gridsize, latstep, longstep):
        latlength = gridsize/2
        longlength = gridsize/2
        latmax = latstep * latlength + latcenter
        latmin = latcenter - latstep * latlength
        longmax = longstep * longlength + longcenter
        longmin = longcenter - longstep * longlength
        latstep = (latmax- latmin) / (2* latlength)
        longstep = (longmax - longmin) / (2* longlength)
        return {'latlength':latlength, 'longlength':longlength, 'latmax':latmax,'latmin':latmin,
                'longmax':longmax, 'longmin':longmin, 'latstep':latstep, 'longstep':longstep}

    @staticmethod
    def calculate_square_sides(latmax, latmin,longmax, longmin):
        right_side = vincenty((latmax, longmax), (latmin, longmax)).meters
        left_side = vincenty((latmax, longmin), (latmin, longmin)).meters
        up_side = vincenty((latmax, longmin), (latmax, longmax)).meters
        down_side = vincenty((latmin, longmin), (latmin, longmax)).meters
        return [right_side, left_side, up_side, down_side]

    @staticmethod
    def squares_coordinates_grid(latmin, longmin, longmax, latlength, latstep, longstep):
        '''Define first square center'''
        square_center_lat = latmin + latstep / 2
        square_center_lon = longmin + longstep / 2
        newSquareid = []
        squares = []
        lats = []
        lngs = []
        for i in range((int(latlength) * 2) ** 2):
            squares.append(i)
            lats.append(square_center_lat)
            lngs.append(square_center_lon)
            square_center_lon += longstep
            if square_center_lon > longmax:
                square_center_lat += latstep
                square_center_lon = longmin + longstep / 2
            x = floor((lats[-1] - latmin) / latstep)
            y = floor((lngs[-1] - longmin) / longstep)
            x = min(x, latlength * 2 - 1)
            y = min(y, latlength * 2 - 1)
            dx = x - latlength
            dy = y - latlength
            r = max(-dx, dx + 1, -dy, dy + 1)
            id = 4 * ((r - 1) ** 2)
            if dy == -r:
                id += dx + r
            elif dx == r - 1:
                id += 2 * r + dy + r - 1
            elif dy == r - 1:
                id += 4 * r - 1 + (r - 2 - dx)
            elif dx == -r:
                id += 6 * r - 2 + (r - 2 - dy)
            newSquareid.append(id)
        squares_coordinates = pd.DataFrame({'square_id': newSquareid, 'lat': lats,
                                            'lng': lngs, 'legacy_square_id': squares})
        return squares_coordinates

    @staticmethod
    def check_square_size(squares_coordinates):
        squares_coordinates = squares_coordinates.sort_values('square_id').reset_index()
        square_0_lat = squares_coordinates.iloc[0].lat
        square_0_lng = squares_coordinates.iloc[0].lng
        square_1_lat = squares_coordinates.iloc[1].lat
        square_1_lng = squares_coordinates.iloc[1].lng
        square_3_lat = squares_coordinates.iloc[3].lat
        square_3_lng = squares_coordinates.iloc[3].lng
        vertical_size = vincenty((square_0_lat, square_0_lng), (square_1_lat, square_1_lng)).meters
        horizontal_size = vincenty((square_0_lat, square_0_lng), (square_3_lat, square_3_lng)).meters
        return [vertical_size, horizontal_size]

    def make_city_grid(self, manual_gridsize=None, square_size=100., town=None):
        self.loger.write_to_log('input', self.input)
        region = self.state
        if not town:
            town = self.city
        self.loger.write_to_log('city_geocoded', town)
        steps = self.calculate_steps(square_size)
        borders = self.calculate_borders()
        distances = self.calc_distances(borders)
        gridsize = self.calc_grid_size(distances=distances, square_size=square_size, manual_gridsize=manual_gridsize)
        city_id = self.get_new_city_id()
        country_id = self.get_country_id()
        population = self.get_population(self.english_name)
        square_grid_parametets = self.make_it_square(self.lat, self.lng, gridsize, steps[0], steps[1])
        cities_grids_attributes = {'region':region, 'town':town, 'city_id':city_id,
                                   'latcenter': self.lat, 'longcenter': self.lng, 'lat': self.lat, 'long': self.lng,
                                   'latstep': square_grid_parametets['latstep'],
                                   'longstep': square_grid_parametets['longstep'],
                                   'latlength': square_grid_parametets['latlength'],
                                   'longlength': square_grid_parametets['longlength'],
                                   'latmax': square_grid_parametets['latmax'],
                                   'longmin': square_grid_parametets['longmin'],
                                   'latmin': square_grid_parametets['latmin'],
                                   'longmax': square_grid_parametets['longmax'],
                                   'Население': population, 'country_id': country_id}
        polygon_sides = self.calculate_square_sides(cities_grids_attributes['latmax'],
                                                    cities_grids_attributes['latmin'],
                                                    cities_grids_attributes['longmax'],
                                                    cities_grids_attributes['longmin'])
        self.squares_coordinates = self.squares_coordinates_grid(cities_grids_attributes['latmin'],
                                                                 cities_grids_attributes['longmin'],
                                                                 cities_grids_attributes['longmax'],
                                                                 cities_grids_attributes['latlength'],
                                                                 cities_grids_attributes['latstep'],
                                                                 cities_grids_attributes['longstep'])
        square_sides = self.check_square_size(self.squares_coordinates)
        self.loger.write_to_log('square_sides', square_sides)
        self.loger.write_to_log('polygon_sides', polygon_sides)
        return cities_grids_attributes


def main():
    input_string = 'Россия, Амурская область, Тында'
    city_dict = ml_geocoder.geocode(input_string)
    print(city_dict)
    City = MetadataCreate(city_dict)
    cities_grids_attributes = City.make_city_grid(square_size=100.)
    City.city_grid_to_database(cities_grids_attributes, check_dup=False)


class Metadata:
    def __init__(self, city_identifier, db=None):
        self.city_id = 0
        self.town = ''
        if not db:
            self.db = MLData()
        else:
            self.db = db
        self.city_identifier = city_identifier
        self.city_id_town_handler()

    def city_id_town_handler(self):
        try:
            self.town = self.get_town_by_id(self.city_identifier)
            self.city_id = self.city_identifier
        except Exception:
            try:
                self.city_id = self.get_id_by_town(self.city_identifier)
                self.town = self.city_identifier
            except:
                raise Exception('No such city with identifier: ' + str(self.city_identifier))

    def get_id_by_town(self, town):
        df = pd.read_sql("select city_id from metadata.cities_grids where town = '"+town+"'", self.db.engine)
        if df.shape[0] != 0:
            return df.at[0, 'city_id']
        else:
            raise Exception('No registered city with name: '+town)

    def get_town_by_id(self, city_id):
        df = pd.read_sql('select town from metadata.cities_grids where city_id = ' + str(city_id), self.db.engine)
        if df.shape[0] != 0:
            return df.at[0, 'town']
        else:
            raise Exception('No registered city with id: ' + str(city_id))


if __name__ == '__main__':
    main()

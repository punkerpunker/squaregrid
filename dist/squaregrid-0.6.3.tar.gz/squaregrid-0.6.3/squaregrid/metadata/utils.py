from mlbase.db.query import Query


def cut_rivers(df, db=None):
    q = Query('metadata.no_rivers', db)
    q.select(['city_id_dup as city_id', 'square_id_dup as square_id'])
    df_nor = q.get()
    intersection = df.merge(df_nor, on=['city_id', 'square_id'], how='inner')
    return intersection

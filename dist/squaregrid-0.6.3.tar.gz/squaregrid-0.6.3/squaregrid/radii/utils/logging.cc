#include "logging.h"

INITIALIZE_EASYLOGGINGPP

def get_build_location():
    pass

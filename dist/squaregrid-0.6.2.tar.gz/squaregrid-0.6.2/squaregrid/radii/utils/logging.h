#pragma once
#include <easylogging++.h>
